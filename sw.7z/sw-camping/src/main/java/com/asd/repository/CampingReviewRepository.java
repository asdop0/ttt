package com.asd.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asd.model.CampingReview;

public interface CampingReviewRepository extends JpaRepository<CampingReview, Long>{

}
