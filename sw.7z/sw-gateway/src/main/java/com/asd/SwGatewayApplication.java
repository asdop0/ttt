package com.asd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwGatewayApplication.class, args);
	}

}
